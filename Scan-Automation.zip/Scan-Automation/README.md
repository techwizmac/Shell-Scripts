Scan Automation
---------------

Simple script to automate usage of some basic scan tools.
it requires a file called host to be created and containing the IP/host name of the target.
When the script is run, it will create a text file called Scan-Result to dump results of the scan process
depending on what was selected.

Subsequent iterations of this script should make the list of tools more extensive and be able to indicate which tools
to run and which ones not to. Eventually I am planning to move this to a PYthon based tool.


